import uuid
from datetime import datetime

from sqlalchemy import DateTime, func
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


class Base(DeclarativeBase):
    """القاعدة المشتركة لكل الـ models بالنظام."""
    pass


class UUIDPrimaryKeyMixin:
    """يضيف مفتاح أساسي UUID يتولّد تلقائيًا (يحتاج extension: pgcrypto)."""
    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        primary_key=True,
        server_default=func.gen_random_uuid(),
    )


class TimestampMixin:
    """يضيف عمود created_at تلقائيًا لكل جدول يستخدمه."""
    created_at: Mapped[datetime] = mapped_column(
        DateTime, server_default=func.now(), nullable=False
    )
