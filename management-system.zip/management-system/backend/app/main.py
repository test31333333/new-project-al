from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.modules.auth.routes import router as auth_router
from app.modules.users.routes import router as users_router
from app.modules.sections.routes import router as sections_router
from app.modules.dashboard.routes import router as dashboard_router
from app.modules.files.routes import router as files_router
from app.modules.hr.routes import router as hr_router

app = FastAPI(title="Management System API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth_router, prefix="/api/v1/auth", tags=["auth"])
app.include_router(users_router, prefix="/api/v1/users", tags=["users"])
app.include_router(sections_router, prefix="/api/v1/sections", tags=["sections"])
app.include_router(dashboard_router, prefix="/api/v1/dashboard", tags=["dashboard"])
app.include_router(files_router, prefix="/api/v1/files", tags=["files"])
app.include_router(hr_router, prefix="/api/v1/hr", tags=["hr"])


@app.get("/health")
def health():
    return {"status": "ok"}
