import uuid
from datetime import date

from sqlalchemy import Date, ForeignKey, String
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.common.base_model import Base, TimestampMixin, UUIDPrimaryKeyMixin


class HRDepartment(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "hr_departments"

    name: Mapped[str] = mapped_column(String(150), nullable=False)
    parent_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("hr_departments.id"), nullable=True
    )
    manager_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("hr_employees.id", ondelete="SET NULL", use_alter=True, name="fk_hr_departments_manager"),
        nullable=True,
    )


class HREmployee(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "hr_employees"

    user_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"), nullable=True
    )
    department_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("hr_departments.id", ondelete="SET NULL"), nullable=True
    )
    employee_code: Mapped[str | None] = mapped_column(String(50), unique=True, nullable=True)
    full_name: Mapped[str] = mapped_column(String(150), nullable=False)
    national_id: Mapped[str | None] = mapped_column(String(50), nullable=True)
    phone: Mapped[str | None] = mapped_column(String(50), nullable=True)
    email: Mapped[str | None] = mapped_column(String(150), nullable=True)
    job_title: Mapped[str | None] = mapped_column(String(150), nullable=True)
    employment_status: Mapped[str] = mapped_column(String(30), nullable=False, default="active")
    hire_date: Mapped[date | None] = mapped_column(Date, nullable=True)


class HREmployeeDocument(Base, UUIDPrimaryKeyMixin, TimestampMixin):
    __tablename__ = "hr_employee_documents"

    employee_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("hr_employees.id", ondelete="CASCADE"), nullable=False
    )
    file_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("files.id", ondelete="CASCADE"), nullable=False
    )
    document_type: Mapped[str | None] = mapped_column(String(100), nullable=True)
