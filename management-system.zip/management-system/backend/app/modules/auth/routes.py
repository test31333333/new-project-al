from fastapi import APIRouter

router = APIRouter()

# TODO: أضف نقاط الـ API الفعلية لقسم auth هنا
