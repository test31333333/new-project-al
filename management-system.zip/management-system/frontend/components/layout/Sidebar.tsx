"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard,
  Users,
  Wallet,
  Boxes,
  ShoppingCart,
  Briefcase,
  Package,
  BarChart3,
  Lock,
} from "lucide-react";

type NavItem = {
  label: string;
  href: string;
  icon: React.ComponentType<{ size?: number; className?: string }>;
  comingSoon?: boolean;
};

const navItems: NavItem[] = [
  { label: "لوحة التحكم", href: "/dashboard", icon: LayoutDashboard },
  { label: "الموارد البشرية", href: "/hr", icon: Users },
  { label: "القسم الثاني ", href: "/finance", icon: Wallet, comingSoon: true },
  { label: "القسم الثالث", href: "/inventory", icon: Boxes, comingSoon: true },
  { label: "القسم الرابع", href: "/procurement", icon: ShoppingCart, comingSoon: true },
  { label: "الفسم الخامس", href: "/sales-crm", icon: Briefcase, comingSoon: true },
  { label: "القسم السادس", href: "/projects", icon: Package, comingSoon: true },
  { label: "القسم السابع ", href: "/reports", icon: BarChart3, comingSoon: true },
];

export default function Sidebar() {
  const pathname = usePathname();

  return (
    <aside className="flex h-screen w-64 flex-col border-l border-slate-800 bg-slate-900 text-slate-200">
      <div className="flex items-center gap-2 px-5 py-5 border-b border-slate-800">
        <div className="flex h-8 w-8 items-center justify-center rounded-md bg-teal-500 text-sm font-bold text-slate-900">
          M
        </div>
        <span className="text-base font-semibold tracking-tight">
          نظام الإدارة
        </span>
      </div>

      <nav className="flex-1 overflow-y-auto px-3 py-4">
        <ul className="flex flex-col gap-1">
          {navItems.map((item) => {
            const isActive =
              pathname === item.href || pathname?.startsWith(item.href + "/");
            const Icon = item.icon;

            if (item.comingSoon) {
              return (
                <li key={item.href}>
                  <div className="flex cursor-not-allowed items-center justify-between rounded-lg px-3 py-2 text-sm text-slate-500">
                    <span className="flex items-center gap-3">
                      <Icon size={18} className="opacity-50" />
                      {item.label}
                    </span>
                    <Lock size={13} className="opacity-40" />
                  </div>
                </li>
              );
            }

            return (
              <li key={item.href}>
                <Link
                  href={item.href}
                  className={`flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors ${
                    isActive
                      ? "bg-teal-500/10 text-teal-400 font-medium border-r-2 border-teal-400"
                      : "text-slate-300 hover:bg-slate-800 hover:text-white"
                  }`}
                >
                  <Icon size={18} />
                  {item.label}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>

      <div className="border-t border-slate-800 px-5 py-4 text-xs text-slate-500">
        الإصدار 0.1 — MVP
      </div>
    </aside>
  );
}
