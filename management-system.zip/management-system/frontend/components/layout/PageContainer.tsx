import type { ReactNode } from "react";
import Sidebar from "./Sidebar";

export default function PageContainer({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-screen bg-slate-50" dir="rtl">
      <Sidebar />
      <main className="flex-1 overflow-y-auto">{children}</main>
    </div>
  );
}
