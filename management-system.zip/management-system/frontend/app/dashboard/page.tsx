export default function DashboardPage() {
  return (
    <main className="p-6">
      <h1 className="text-2xl font-bold">لوحة التحكم</h1>
      <p className="text-gray-500 mt-2">
        صفحة الداشبورد (Placeholder) - سيتم بناء الرسوم البيانية والمهام والتقارير هنا لاحقًا.
      </p>
    </main>
  );
}
