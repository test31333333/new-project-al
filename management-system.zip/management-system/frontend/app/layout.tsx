import "./globals.css";
import type { ReactNode } from "react";
import PageContainer from "@/components/layout/PageContainer";

export const metadata = {
  title: "Management System",
  description: "نظام إدارة متكامل",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <body>
        <PageContainer>{children}</PageContainer>
      </body>
    </html>
  );
}
