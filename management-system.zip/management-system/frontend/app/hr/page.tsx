export default function HRPage() {
  return (
    <main className="p-6">
      <h1 className="text-2xl font-bold">الموارد البشرية</h1>
      <p className="text-gray-500 mt-2">صفحة قسم الموارد البشرية (Placeholder).</p>
    </main>
  );
}
